# VLA-Jspace backfill — 53 remaining cells

The VLA-Jspace rerank sweep finished at **787 of 840 cells**. This job runs the
**53 missing ones**. Nothing else needs rerunning.

## The command

```bash
kubectl create -f job_vjs_backfill.yaml
```

That's it. No edits needed — the file is validated as-is.

## Expect it to be REFUSED at first

```
admission webhook "job.nrp-nautilus.io" denied the request:
Your pods resources utilization is too low for account ...
```

This is the Nautilus account-level utilization gate, **not a problem with the
YAML**. It fires while our account holds GPUs at low average utilization. As of
handoff, `navsafe-drivor-ss` holds 24 GPUs averaging ~32% (each worker pins the
renderer to GPU 0 and the policy to GPU 1; the policy GPU idles at 1–2%).

Two things that do **not** help — both tested:

- **Shrinking the request.** Denied identically at 8, 2, and 1 worker. The gate
  is absolute, not proportional. Don't bother probing sizes.
- **Deleting terminated pods.** Terminated pods hold no GPU allocation.

What does work: **retry on a loop until it's admitted.** It clears once
`navsafe-drivor-ss` finishes or is killed (its `activeDeadlineSeconds` expires
**2026-09-11 01:00:18Z**), which releases 24 GPUs.

```bash
# retry every 60s until admitted
until kubectl create -f job_vjs_backfill.yaml 2>&1 | grep -q created; do
  sleep 60
done
```

If you want it sooner, scale down or delete `navsafe-drivor-ss` first — that
frees the gate but costs that job's coverage:

```bash
kubectl delete job navsafe-drivor-ss -n cogrob     # only if you accept the tradeoff
```

## Prerequisites — all already in place, verified at handoff

| dependency | state |
|---|---|
| ConfigMap `navsafe-vjs-cfg` | present, keys `run_worker_vjs.sh`, `models_vjs.tsv`, `models_drivor_ss.tsv` |
| PVC `avl-west-vol` | mounted at `/avl-west` |
| PVC `horuan-hugsim-vol` | mounted at `/hugsim-storage` |
| Secret `ngc-api-key` | referenced for `NGC_API_KEY` |
| Secret `hf-token` | referenced for `HF_TOKEN` |
| `orphaned_cells.tsv` | 53 rows, sha256 `b06202bb39162ab6` |

Nothing needs creating. The job is `namespace: cogrob`.

## What it will do

- **8 workers**, Indexed, 2 GPUs each, `backoffLimit: 50`,
  `activeDeadlineSeconds: 21600` (6 h — ample; 53 cells is well under 1 h)
- Reads the cell list from
  `BACKFILL_LIST=/avl-west/navsafe_eval/vla_jspace/orphaned_cells.tsv`
  (format `<seed>\t<token>`, seed as a bare number: `0`, `1`, `1024`)
- Writes into `OUTROOT=/avl-west/navsafe_eval/vla-jspace` — the **same** root as
  the existing 787 cells, under slug `recogdrive_il_vjsrerank`
- `MODELS_TSV` is intentionally unset; the worker defaults to
  `/cfg/models_vjs.tsv`, which is the correct rerank row
  (`recogdrive_il_vjsrerank` / `recogdrive_rerank`, `NAVSAFE_RERANK_N=16`)
- Pinned to NexusSim `a8144b8821ed743262099c2564d2f4260ad59d6d`

**Safe to re-run.** A cell is skipped when it has *both* a `[eval_py123d] DONE.`
log line and a `navsafe_metrics.json` (`run_worker_vjs.sh:328`), so the 787
already-scored cells are never recomputed.

## Monitoring

```bash
kubectl get job navsafe-vjs-backfill -n cogrob
kubectl get pods -n cogrob | grep backfill
kubectl logs -n cogrob -l app=navsafe-vjs --tail=20
```

Progress — run from **a live worker pod**, not `vjs-py2` (that debug pod is
`phase=Failed` as of handoff):

```bash
P=$(kubectl get pods -n cogrob --no-headers | grep backfill | awk '$3=="Running"{print $1}' | head -1)
kubectl exec -n cogrob "$P" -- bash -lc \
  'find /avl-west/navsafe_eval/vla-jspace -name navsafe_metrics.json | wc -l'
```

**Done when that reaches 840** (from 787). Count on `navsafe_metrics.json` —
the pipeline does not write `metrics.json` except as an unscorable stub.

## Two cells expected to fail again

Not backfill bugs:

- `seed1/0777f5a7263758be` — renderer CUDA OOM at frame 0 (146 MiB alloc with
  74 MiB free on a 24 GB 3090). Hard failure.
- Any cell that trips the same renderer OOM. 33 cells needed retries in the main
  sweep and 21 of 24 recovered, so most of the 53 should be fine — 50 of them
  were never attempted at all, they were stranded when their worker slice
  exited, which is why they're missing rather than failed.

`5d12ad55fdd858e1` is **not** in the list. It scored (unscorably, an
`infra_failure` at frame ~405 in all 3 seeds), so re-running it would just burn
renderer setup.

## Why these 53 were missing

Each was orphaned when its worker slice exited. An Indexed Job never respawns a
completed index, so any cells that slice hadn't reached were stranded. Not a
scoring failure. The list was derived from `job.status.completedIndexes` (the
durable record) and verified to match the true missing set exactly — 0 spurious
rows, 0 omissions.
